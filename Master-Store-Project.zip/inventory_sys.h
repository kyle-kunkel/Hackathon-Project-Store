#ifndef INVENTORY_SYS
#define INVENTORY_SYS

#include <string>

using namespace std;

class InventoryItem{
  private:
    string item_name;
    string item_category;
    string item_subcat;
    string item_price;
    string item_stock; 

  public:
    string GetItemName(){ return item_name; }
    string GetItemCategory(){ return item_category; }
    string GetItemSubcat(){ return item_subcat; }
    string GetItemPrice(){ return item_price; }
    string GetItemStock(){ return item_stock; }

    void SetItemName( string input_item_name ){ item_name = input_item_name; }
    void SetItemCategory( string input_item_category ){ item_category = input_item_category; }
    void SetItemSubcat( string input_item_subcat ){ item_subcat = input_item_subcat; }
    void SetItemPrice( string input_item_price ){ item_price = input_item_price; }
    void SetItemStock( string input_item_stock ){ item_stock = input_item_stock; }

    void PrintInventoryMap();

    void ModifyItemName();
    void ModifyItemCategory();
    void ModifyItemSubcat();
    void ModifyItemPrice();
    void ModifyItemStock();
};

#endif