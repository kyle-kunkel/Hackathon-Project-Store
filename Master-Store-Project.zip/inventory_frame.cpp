/*
#include <iostream>
#include <unordered_map>
#include <fstream>
#include <iomanip>

using namespace std;

// 1. Create struct Item

// Don't forget the function declaration

int main() {
  // 2.1. Define a hashmap with a string key and an Item value
  // 2.2. Define an Item called parsed_item

  // 3. Open and read file inventory_list.txt
      // 4. Parse each line from the file into parsed_item
      // 5. Insert data into hashmap   key: item_name   value: parsed_item

  // 6.2. Test your code by printing out the hashmap
  // 7.2. Test your code by sorting your hashmap then printing it out again

}

// 6.1. Create a function called PrintInventoryMap to print out all the items in the hashmap

// 7.1. Implement HashSort() to sort the hashmap
*/

/*
Kyle Kunkel
8 Dec. 2020
*/