#include "inventory_sys.h"
#include <string>

using namespace std;

void InventoryItem::PrintInventoryMap(){
  
}

void InventoryItem::ModifyItemName(){}
void InventoryItem::ModifyItemCategory(){}
void InventoryItem::ModifyItemSubcat(){}
void InventoryItem::ModifyItemPrice(){}
void InventoryItem::ModifyItemStock(){}