#include <iostream>
#include <unordered_map>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include "inventory_sys.h"

using namespace std;

void PrintInventoryMap( unordered_map<string, InventoryItem> inventory_map );

int main() { 
  
  
  // 2.1. Define a hashmap with a string key and an Item value
  unordered_map<string, InventoryItem> inventory_map;
  // 2.2. Define an Item called parsed_item
  InventoryItem parsed_item;
  string item_name;
  string item_category;
  string item_subcat;
  string item_price;
  string item_stock;
  vector<string> item_parse;

  // 3. Open and read file inventory_list.txt
  string line;
  ifstream inventory_list_input("inventory_list.txt");
  if( inventory_list_input.is_open() ){
    while( getline(inventory_list_input, line) ){
      // 4. Parse each line from the file into parsed_item
      stringstream parse_line(line);
      string token;
      while( getline(parse_line, token, ' ') ){
        //cout << "TOKEN: " << token << " ";
        item_parse.push_back(token);
      }
      // TEST item_parse vector output
      /*
      cout << endl;
      for( int i = 0; i < 5; i++ ){
        cout << "PARSE: " << item_parse[i] << " ";
      }
      cout << endl;
      */
      /*
      parse_line >> item_name;
      parse_line >> item_category;
      parse_line >> item_subcat;
      parse_line >> item_price;
      parse_line >> item_stock;
      */
      //item_price = static_cast<double>(item_price);
      //item_stock = static_cast<int>(item_stock);
      parsed_item.SetItemName( item_parse[0] );
      parsed_item.SetItemCategory( item_parse[1] );
      parsed_item.SetItemSubcat( item_parse[2] );
      parsed_item.SetItemPrice( item_parse[3] );
      parsed_item.SetItemStock( item_parse[4] );
      
      // 5. Insert data into hashmap   key: item_name   value: parsed_item
      inventory_map[parsed_item.GetItemName()] = parsed_item;

      // print test
      
      cout << "TEST: " << parsed_item.GetItemName() << " "
                       << parsed_item.GetItemCategory() << " "
                       << parsed_item.GetItemSubcat() << " "
                       << parsed_item.GetItemPrice() << " "
                       << parsed_item.GetItemStock() << " " << endl;
      
    }
  }

  // 6.2. Test your code by printing out the hashmap
 // PrintInventoryMap(inventory_map);

}

// 6.1. Create a function called PrintInventoryMap to print out all the items in the hashmap
// SOME ERRORS HERE WITH PRINTING
void PrintInventoryMap( unordered_map<string, InventoryItem> inventory_map ){
  for( auto item : inventory_map ){
    cout << item.first << endl
         << item.second.GetItemName() << " "
         << item.second.GetItemCategory() << " "
         << item.second.GetItemSubcat() << " "
         << item.second.GetItemPrice() << " "
         << item.second.GetItemStock() << " "
         << endl << endl;
  }
}

// 7 Implement HashSort() to sort the hashmap

/*
Kyle Kunkel
8 Dec. 2020
*/